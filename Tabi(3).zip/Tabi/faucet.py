#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
建议运行在py3.10版本上
"""

import asyncio
from loguru import logger;
import sqlite3;
import time;
from datetime import datetime;
import tqdm;
import tls_client;
import urllib3
import multiprocessing;
import json

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

f = open("accounts.txt","r")
accounts = f.readlines()
f.close()
accounts = [i.split(",")[0] for i in accounts]

with open("./fail_faucet.txt", "w") as f:
    f.truncate(0)
with open('./fail_faucet_detail.txt', 'w') as f:
    f.truncate(0)

class WaterHandler:
    def __init__(self) -> None:
        self.headers = {
            'authority': 'faucet.testnet.tabichain.com',
             "Content-Type": "application/json",
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'cache-control': 'no-cache',
            # 'cookie': '_ga=GA1.1.294572172.1709551654; _ga_SG5SPXJNL6=GS1.1.1709551653.1.1.1709553048.0.0.0; __cuid=93405934a92445fda37451e7506f5876; amp_fef1e8=3d740432-36dc-42d0-a52f-d76d713539e9R...1ho4l4msm.1ho4l7378.i.2.k',
            'pragma': 'no-cache',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        }

        self.faucet_url = "https://faucet-api.testnet.tabichain.com/api/faucet";
        self.db_name = "berachain"
        self.expire_time = '-24 hours'

    def water( self, _address):
        data = {
            'address':_address
        }
        proxeis = {"http": f'http://127.0.0.1:7890', "https": f'http://127.0.0.1:7890'} 
        if( proxeis == None ):
            raise ValueError("ProxyError");
    
        proxy = {"http":proxeis['http']};

        session = tls_client.Session(client_identifier="chrome112",random_tls_extension_order=True)

        res = session.post(self.faucet_url,
                                   json=data,
                                   proxy=proxy, 
                                   headers=self.headers);


        print(f'json: {res.json()} ')

        if 'success' in res.text and res.json()['success']:
            print(f'address: {_address} 领水成功!!!')
        else:
            with open('./fail_faucet.txt', 'a') as f:
                #将领水失败的地址存入.txt文件中
                f.writelines(_address+',\n')
            if 'message' in res.text and res.json()['message']:
                with open('./fail_faucet_detail.txt', 'a') as f:
                    #将领水失败的地址及错误信息存入.txt文件中
                    f.writelines(_address+'--->'+ res.json()['message'] +'\n')
 


if __name__ == '__main__':
    print(accounts)
    for i in range(len(accounts)):
        wt = WaterHandler()
        wt.water(accounts[i])
        time.sleep(5)
        