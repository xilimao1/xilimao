accounts.txt  Tabi 的接收地址 按照给出的格式
fail_faucet.txt 领水失败的地址	【每次执行会被清空】
fail_faucet_detail.txt  领水失败的地址+错误信息 【每次执行会被清空】


使用： python3 faucet.py


注意：：：：：no module XXX     执行 pip3 install XXX